#ifndef __ENUM_EFFECTS_H__
#define __ENUM_EFFECTS_H__

enum {
	e_equalizer,
	e_delay,
	e_hall,
	e_volume,
	e_dummy
};

#endif
