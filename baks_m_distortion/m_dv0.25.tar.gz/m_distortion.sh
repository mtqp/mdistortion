make
jackd -dalsa $
./m_distortion rock
