#ifndef __M_WINDOW_H__
#define __M_WINDOW_H__

#include <gtk/gtk.h>
#include <stdlib.h>

GtkWindow* open_sub_window(char* window);

#endif
