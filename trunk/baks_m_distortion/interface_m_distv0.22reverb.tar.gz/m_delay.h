#ifndef __DELAY_H__
#define __DELAY_H__

#include <stdlib.h>
#include <stdio.h>

#define FLOAT_SIZE 4

typedef struct _m_delay {
	int delay_size;
	float* delay_buf;
} m_delay;

m_delay* delay_new (int size);
#endif
