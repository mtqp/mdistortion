#ifndef __ENUM_DIST_H__
#define __ENUM_DIST_H__

enum {
	e_log_rock,
	e_log_rock_II,
	e_hell_sqrt,
	e_psychedelic_if,
	e_by_60s,
	e_fuzzy_dark_pow_IV,
	e_rare_cuadratic,
	e_random_day,
	e_mute,
	e_by_pass,
	e_delay		//esta extra, quizas ni siquiera vaya...
};

#endif
