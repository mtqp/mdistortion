#ifndef __M_WINDOW_H__
#define __M_WINDOW_H__

#include <gtk/gtk.h>
#include <stdlib.h>

#define window_save 1
#define window_info 0

void open_window(int window_name);

#endif
