
#include "m_delay.h"

m_delay* delay_new (int size){
	m_delay* d = (m_delay*) malloc(sizeof(m_delay));
	if(d == NULL){
		printf("Couldn't malloc Delay Structure\n");
		return NULL;
	}
	else {
		d->delay_size = size;
		d->delay_buf = (float*) malloc(d->delay_size*FLOAT_SIZE);
		if(d->delay_buf == NULL) {
			printf("Couldn't malloc Buffer Delay Structure\n");
			return NULL;
		} else {
			printf("	Delay Effect Set\n");
			int i;
			for(i=0;i<d->delay_size;i++){
				d->delay_buf[i] = 0.0;
			}
			return d;
		}
	}
}
